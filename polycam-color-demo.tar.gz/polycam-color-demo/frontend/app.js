import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";
import { OrbitControls } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/GLTFLoader.js";

const API_URL = "http://127.0.0.1:8000/api/model/color";
const MODEL_URL = "./models/sample.glb";

const viewer = document.getElementById("viewer");
const colorPicker = document.getElementById("colorPicker");
const meshNameInput = document.getElementById("meshName");
const modelIdInput = document.getElementById("modelId");
const applyColorBtn = document.getElementById("applyColorBtn");
const sendColorBtn = document.getElementById("sendColorBtn");
const selectedColorText = document.getElementById("selectedColorText");
const selectedMeshText = document.getElementById("selectedMeshText");
const statusOutput = document.getElementById("statusOutput");

let scene, camera, renderer, controls;
let loadedModel = null;

initScene();
loadModel();
animate();

colorPicker.addEventListener("input", () => {
  selectedColorText.textContent = colorPicker.value;
});

applyColorBtn.addEventListener("click", () => {
  applyColorToModel();
});

sendColorBtn.addEventListener("click", async () => {
  await sendColorUpdate();
});

function setStatus(message, append = false) {
  if (append) {
    statusOutput.textContent += `\n${message}`;
  } else {
    statusOutput.textContent = message;
  }
}

function initScene() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x101826);

  const width = viewer.clientWidth || window.innerWidth;
  const height = viewer.clientHeight || window.innerHeight;

  camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
  camera.position.set(0, 1.5, 4);

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(width, height);
  viewer.appendChild(renderer.domElement);

  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.target.set(0, 1, 0);

  const ambientLight = new THREE.AmbientLight(0xffffff, 1.4);
  scene.add(ambientLight);

  const directionalLight = new THREE.DirectionalLight(0xffffff, 2);
  directionalLight.position.set(5, 10, 7);
  scene.add(directionalLight);

  const grid = new THREE.GridHelper(10, 10, 0x334155, 0x1f2937);
  scene.add(grid);

  window.addEventListener("resize", onResize);
}

function onResize() {
  const width = viewer.clientWidth || window.innerWidth;
  const height = viewer.clientHeight || window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height);
}

function loadModel() {
  const loader = new GLTFLoader();

  setStatus("Loading model...");

  loader.load(
    MODEL_URL,
    (gltf) => {
      loadedModel = gltf.scene;
      scene.add(loadedModel);

      fitCameraToObject(loadedModel);
      setStatus("Model loaded successfully.");
    },
    undefined,
    (error) => {
      console.error(error);
      setStatus("Failed to load model. Make sure frontend/models/sample.glb exists and you are serving the frontend through a local HTTP server.");
    }
  );
}

function fitCameraToObject(object) {
  const box = new THREE.Box3().setFromObject(object);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());

  const maxDim = Math.max(size.x, size.y, size.z);
  const fov = camera.fov * (Math.PI / 180);
  let cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2));
  cameraZ *= 1.8;

  camera.position.set(center.x, center.y + maxDim * 0.4, center.z + cameraZ);
  camera.near = maxDim / 100 || 0.1;
  camera.far = maxDim * 100 || 1000;
  camera.updateProjectionMatrix();

  controls.target.copy(center);
  controls.update();
}

function applyColorToModel() {
  if (!loadedModel) {
    setStatus("No model loaded yet.");
    return;
  }

  const chosenColor = colorPicker.value;
  const targetMeshName = meshNameInput.value.trim();

  let changedCount = 0;
  let foundTarget = false;

  loadedModel.traverse((obj) => {
    if (!obj.isMesh) return;

    if (targetMeshName) {
      if (obj.name === targetMeshName) {
        obj.material = obj.material.clone();
        if (obj.material.color) {
          obj.material.color.set(chosenColor);
        }
        foundTarget = true;
        changedCount++;
      }
    } else {
      obj.material = obj.material.clone();
      if (obj.material.color) {
        obj.material.color.set(chosenColor);
      }
      changedCount++;
    }
  });

  selectedColorText.textContent = chosenColor;
  selectedMeshText.textContent = targetMeshName || "All meshes";

  if (targetMeshName && !foundTarget) {
    setStatus(`Mesh '${targetMeshName}' not found. No color applied.`);
    return;
  }

  setStatus(`Applied color ${chosenColor} to ${changedCount} mesh(es).`);

  // Note:
  // Some Polycam-exported models may have texture maps.
  // In those cases, material.color can tint the texture instead of producing a flat solid color.
  // If you need a pure solid color, you may need to remove the map or replace the material.
}

async function sendColorUpdate() {
  const modelId = modelIdInput.value.trim();
  const meshName = meshNameInput.value.trim();
  const color = colorPicker.value;

  if (!modelId) {
    setStatus("Model ID is required before sending.");
    return;
  }

  const payload = {
    modelId,
    meshName,
    color,
    updatedAt: new Date().toISOString()
  };

  setStatus("Sending color update...");

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (!response.ok) {
      setStatus(`API error: ${JSON.stringify(result, null, 2)}`);
      return;
    }

    setStatus(`Success:\n${JSON.stringify(result, null, 2)}`);
  } catch (error) {
    console.error(error);
    setStatus(`Request failed: ${error.message}`);
  }
}

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}
