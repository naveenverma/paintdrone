import re
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, field_validator

app = FastAPI(title="Polycam Color Sync API")

origins = [
    "http://127.0.0.1:5500",
    "http://localhost:5500",
    "http://127.0.0.1:8080",
    "http://localhost:8080",
    "http://127.0.0.1:3000",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

HEX_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


class ColorUpdate(BaseModel):
    modelId: str
    meshName: Optional[str] = ""
    color: str
    updatedAt: str

    @field_validator("modelId")
    @classmethod
    def validate_model_id(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("modelId is required")
        return value.strip()

    @field_validator("color")
    @classmethod
    def validate_color(cls, value: str) -> str:
        value = value.strip()
        if not HEX_COLOR_RE.match(value):
            raise ValueError("color must be a valid hex color like #3366ff")
        return value

    @field_validator("updatedAt")
    @classmethod
    def validate_updated_at(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("updatedAt is required")
        return value.strip()


@app.get("/health")
def health():
    return {
        "success": True,
        "message": "API is healthy",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }


@app.post("/api/model/color")
def receive_color_update(payload: ColorUpdate):
    try:
        print("Received payload:", payload.model_dump())
        return {
            "success": True,
            "message": "Color update received",
            "data": payload.model_dump()
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
