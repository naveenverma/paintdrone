# Polycam Color Editor Demo

A simple demo that:

- loads a Polycam-exported GLB/GLTF model in Three.js
- lets you recolor the whole model or a named mesh
- sends the selected color and metadata to a FastAPI backend

## Project structure

```text
project-root/
  backend/
    main.py
    requirements.txt
  frontend/
    index.html
    app.js
    style.css
    models/
      sample.glb
  README.md
```

## Requirements

- Python 3.10+
- A browser
- A Polycam-exported `.glb` or `.gltf` model

## 1) Put your model in place

Copy your Polycam-exported model file to:

```text
frontend/models/sample.glb
```

If your file is `.gltf`, update `MODEL_URL` in `frontend/app.js`.

## 2) Start the backend

Open a terminal in `backend/` and run:

```bash
python -m venv .venv
```

### Windows

```bash
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

### macOS / Linux

```bash
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

The API will run at:

```text
http://127.0.0.1:8000
```

Test health endpoint:

```text
http://127.0.0.1:8000/health
```

## 3) Start the frontend

Open another terminal in `frontend/` and run a simple local server.

Example with Python:

```bash
python -m http.server 5500
```

Then open:

```text
http://127.0.0.1:5500
```

## How it works

- The frontend uses Three.js `GLTFLoader` to load the model.
- Clicking **Apply Color** updates:
  - all meshes if mesh name is empty
  - only the matching mesh if mesh name is provided
- The app clones materials before recoloring so shared materials do not unintentionally affect multiple parts.
- Clicking **Send Color Update** posts JSON to the FastAPI backend.

## Sample API payload

```json
{
  "modelId": "polycam_123",
  "meshName": "Body",
  "color": "#3366ff",
  "updatedAt": "2026-04-10T20:00:00Z"
}
```

## Important note about textured Polycam models

Some Polycam exports include textures. In those cases, changing `material.color` may only tint the texture instead of replacing it with a flat solid color.

If you need a pure flat color, you may need to:
- remove `material.map`
- replace the material
- or bake/export a modified asset in a separate 3D pipeline

## Integration note

In many real systems, it is better to send:

- `modelId`
- `meshName`
- `color`

to another system and let that system apply the color itself, instead of trying to upload a newly modified GLB every time.

## Troubleshooting

### Model does not load
- Make sure `frontend/models/sample.glb` exists
- Make sure you are running a local HTTP server, not opening `index.html` directly as a file

### API request fails
- Make sure FastAPI is running on port 8000
- Make sure frontend is served on one of the allowed CORS origins in `backend/main.py`

### Mesh name not found
- Leave mesh name empty to recolor all meshes
- Or inspect your model node names in a 3D tool or add logging in traversal
